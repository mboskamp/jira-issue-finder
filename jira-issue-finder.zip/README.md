# Jira Issue Finder

This is a browser extension based on the Mozilla Browser Extension API that provides quick access to your JIRA issues.

On the configuration page for the extension add a base link to your JIRA instance and provide the project key.

Once configured type `jira <project-key> <issue-number>` and the extension will provide the link to the issue.